import java.util.ArrayList;
import java.io.*;

public class CountriesTextFile
{
    private File countriesFile = null;

    public CountriesTextFile()
    {
        countriesFile = new File("countries.txt");
        this.checkFile();
    }

    public ArrayList<String> getCountries()
    {
        // declare the input stream
        BufferedReader in = null;
        try
        {

            // create the input stream
            in = new BufferedReader(
                 new FileReader(countriesFile));

            // create the array list
            ArrayList<String> countries = new ArrayList<>();

            // read each line in the file
            String line = in.readLine();
            while(line != null)
            {
                if (line != null)          // if line is not null,
                    countries.add(line);   // add each country to the array list
                line = in.readLine();      // each line is a country string
            }
            return countries;
        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
            return null;
        }
        finally
        {
            close(in);
        }
    }

    public boolean saveCountries(ArrayList<String> countries)
    {
        PrintWriter out = null;
        try
        {
            checkFile();

            // open output stream for overwriting
            out = new PrintWriter(
                  new BufferedWriter(
                  new FileWriter(countriesFile)));

            for (int i = 0; i < countries.size(); i++)
            {
                // write each country on a separate line
                String country = countries.get(i);
                out.println(country);
            }
        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
            return false;
        }
        finally
        {
            close(out);
        }
        return true;
    }

    // a private method that creates a blank file if the file doesn't already exist
    private void checkFile()
    {
        try
        {
            if (!countriesFile.exists())
                countriesFile.createNewFile();
        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
        }
    }

    // a private method that closes the I/O stream
    private void close(Closeable stream)
    {
        try
        {
            if (stream != null)
                stream.close();
        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
        }
    }
}