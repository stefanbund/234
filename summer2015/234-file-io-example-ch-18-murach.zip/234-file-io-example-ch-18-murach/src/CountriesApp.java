import java.util.ArrayList;
import java.util.Scanner;

public class CountriesApp
{
    public static void main(String args[])
    {
        // display a welcome message
        System.out.println("Welcome to the Countries Maintenance application\n");

        // create the Scanner object
        Scanner sc = new Scanner(System.in);

        // create the DAO object
        CountriesTextFile countriesDAO = new CountriesTextFile();

        // continue until the user enters 3
        int menuNumber = 0;
        while (menuNumber != 3)
        {
            // display menu
            System.out.println("1 - List countries");
            System.out.println("2 - Add a country");
            System.out.println("3 - Exit\n");

            // get input from user
            menuNumber = Validator.getIntWithinRange(sc, "Enter menu number: ", 0, 4);
            System.out.println();

            switch (menuNumber)
            {
                case 1:
                {
                    // read the countries array list from the file
                    ArrayList<String> countries =
                        countriesDAO.getCountries();

                    // display the list
                    for (int i = 0; i < countries.size(); i++)
                    {
                        String country = countries.get(i);
                        System.out.println(country);
                    }
                    System.out.println();
                    break;
                }
                case 2:
                {
                    // read the countries array list from the file
                    ArrayList<String> countries =
                        countriesDAO.getCountries();

                    // get data from user
                    String country = Validator.getRequiredString(sc, "Enter country: ");

                    // add the country to the countries array list
                    countries.add(country);

                    // save the array list and display confirmation message
                    countriesDAO.saveCountries(countries);
                    System.out.println();
                    System.out.println("This country has been saved.\n");

                    break;
                }
                case 3:
                {
                    System.out.println("Goodbye.\n");
                    break;
                }
            }
        }
    }
}