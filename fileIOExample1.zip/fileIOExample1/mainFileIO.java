package fileIOExample1;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class mainFileIO {

	
		 public static void main(String[] args) throws IOException {
			    String input = FilesUtil.readTextFile("///Users/stefanbund/Documents/workspace/fileIOExample1/src/fileIOExample1/file.txt"); ///Users/stefanbund/Documents/workspace/fileIOExample1/src/fileIOExample1
			    System.out.println("stuff from file.txt: " + input);
			    FilesUtil.writeToTextFile("///Users/stefanbund/Documents/workspace/fileIOExample1/src/fileIOExample1/copy.txt", input);
			    
			    System.out.println("stuff from copy.txt: " + FilesUtil.readTextFile("///Users/stefanbund/Documents/workspace/fileIOExample1/src/fileIOExample1/copy.txt"));
			    
			    FilesUtil.readTextFileByLines("///Users/stefanbund/Documents/workspace/fileIOExample1/src/fileIOExample1/file.txt");
			    Path path = Paths.get("file.txt");
			    
			    Scanner sc = new Scanner(System.in);
			  }
	}


